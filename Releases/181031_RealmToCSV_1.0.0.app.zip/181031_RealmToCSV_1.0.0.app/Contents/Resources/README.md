## Realm to CSV
A utility Mac app to convert Realm file (.realm) to CSV (.csv) file.
This app uses API from [Realm Cocoa Converter](https://github.com/realm/realm-cocoa-converter).

## License
The Apache License (Apache)
Copyright (c) 2018 Aromajoin Corporation
